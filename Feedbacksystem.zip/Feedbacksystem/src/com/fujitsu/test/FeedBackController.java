package com.fujitsu.test;


import java.sql.SQLException;
import java.util.List;


public class FeedBackController {
public static void add(FeedBack feedback){
	try {
		FeedBackDao.add(feedback);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
public static void update(FeedBackModel feedback){
	try {
		FeedBackDao.update(feedback);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
public static List<FeedBackComments> feedBackComments() throws SQLException{
	
	return FeedBackDao.feedBackComments();

}
//public static List<FeedBack> findAll() throws SQLException{
//	return FeedBackDao.findAll();
//}
}

