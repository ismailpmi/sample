package com.fujitsu.test;

public class FeedBackComments {
private String username;
private String batch;
private String comments;
public FeedBackComments() {
	super();
	// TODO Auto-generated constructor stub
}
public FeedBackComments(String username, String batch, String comments) {
	super();
	this.username = username;
	this.batch = batch;
	this.comments = comments;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getBatch() {
	return batch;
}
public void setBatch(String batch) {
	this.batch = batch;
}
public String getComments() {
	return comments;
}
public void setComments(String comments) {
	this.comments = comments;
}
@Override
public String toString() {
	return "FeedBackComments [username=" + username + ", batch=" + batch + ", comments=" + comments + "]";
}

}
