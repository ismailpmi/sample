package com.fujitsu.test;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FeedBackDao {
public static void add(FeedBack feedback) throws SQLException{
	Connection connection = ConnectionUtil.getConnection();
	String sql = "insert into registers(username,email,designation,batch,contactnumber,password) values(?,?,?,?,?,?)";
	PreparedStatement pst = connection.prepareStatement(sql);
	pst.setString(1, feedback.getUserName());
	pst.setString(2, feedback.getEmail());
	pst.setString(3, feedback.getDesignation());
	pst.setString(4, feedback.getBatch());
	pst.setLong(5, feedback.getContactNumber());
	pst.setString(6, feedback.getPassword());
	pst.executeUpdate();

}
public static List<FeedBackModel> findAllBatch1() throws SQLException {
	Connection connection = ConnectionUtil.getConnection();
	String sql =  "select registers.username,registers.batch,feedbacks.comments from registers inner join feedbacks on registers.username=feedbacks.username";
    PreparedStatement pst=connection.prepareStatement(sql);
	ResultSet rs=pst.executeQuery();
	List<FeedBackModel> feedbacks=new ArrayList<>();

	while(rs.next()){
		if(rs.getString("batch").equals("Batch1")){
			FeedBackModel feedback=new FeedBackModel();
		feedback.setUsername(rs.getString("username"));
		feedback.setComments(rs.getString("comments"));
		feedbacks.add(feedback);
		}
		/*else if(rs.getString("batch").equals("batch2")){
			FeedBackModel feedback=new FeedBackModel();
			feedback.setUsername(rs.getString("username"));
			feedback.setComments(rs.getString("comments"));
			feedbacks.add(feedback);
		}*/
	}
return feedbacks;
}
public static List<FeedBackModel> findAllBatch2() throws SQLException {
	Connection connection = ConnectionUtil.getConnection();
	String sql =  "select registers.username,registers.batch,feedbacks.comments from registers inner join feedbacks on registers.username=feedbacks.username";
    PreparedStatement pst=connection.prepareStatement(sql);
	ResultSet rs=pst.executeQuery();
	List<FeedBackModel> feedbacks=new ArrayList<>();

	while(rs.next()){
		if(rs.getString("batch").equals("Batch2")){
			FeedBackModel feedback=new FeedBackModel();
		feedback.setUsername(rs.getString("username"));
		feedback.setComments(rs.getString("comments"));
		feedbacks.add(feedback);
		}
		/*else if(rs.getString("batch").equals("batch2")){
			FeedBackModel feedback=new FeedBackModel();
			feedback.setUsername(rs.getString("username"));
			feedback.setComments(rs.getString("comments"));
			feedbacks.add(feedback);
		}*/
	}
return feedbacks;
}
public static void update(FeedBackModel feedback) throws SQLException {
	Connection connection = ConnectionUtil.getConnection();
	String sql = "insert into feedbacks(username,comments) values(?,?)";
	PreparedStatement pst = connection.prepareStatement(sql);
	pst.setString(1, feedback.getUsername());
	pst.setString(2, feedback.getComments());
	pst.executeUpdate();
}
public static List<FeedBackComments> feedBackComments() throws SQLException{
	Connection connection = ConnectionUtil.getConnection();
	String sql = "select registers.username,registers.batch,feedbacks.comments from registers inner join feedbacks on registers.username=feedbacks.username";
	PreparedStatement pst = connection.prepareStatement(sql);
	ResultSet rs = pst.executeQuery();
	List<FeedBackComments> feedbacks = new ArrayList<>();
	while (rs.next()) {
		
		
		FeedBackComments feedback = new FeedBackComments();
		feedback.setUsername(rs.getString("username"));
		feedback.setBatch(rs.getString("batch"));
		feedback.setComments(rs.getString("comments"));
		feedbacks.add(feedback);
	
	}
	return feedbacks;
}
public FeedBack findByUserNameAndPassword(FeedBack feedback) throws SQLException {
	Connection connection = ConnectionUtil.getConnection();
	String sql = "select username,password from registers where username=? and password=?";
	PreparedStatement pst = connection.prepareStatement(sql);
	pst.setString(1, feedback.getUserName());
	pst.setString(2, feedback.getPassword());
	ResultSet rs = pst.executeQuery();
	FeedBack feedbackObj = null;
	if (rs.next()) {
		feedbackObj = new FeedBack();
		feedback.setUserName(rs.getString("username"));
		feedback.setPassword(rs.getString("password"));
	}
	return feedbackObj;
}
}