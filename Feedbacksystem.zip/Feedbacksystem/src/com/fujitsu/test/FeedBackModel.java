package com.fujitsu.test;


public class FeedBackModel {
private String username;
private String comments;
public FeedBackModel() {
	super();
	// TODO Auto-generated constructor stub
}
public FeedBackModel(String username, String comments) {
	super();
	this.username = username;
	this.comments = comments;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getComments() {
	return comments;
}
public void setComments(String comments) {
	this.comments = comments;
}
@Override
public String toString() {
	return "FeedBackModel [username=" + username + ", comments=" + comments + "]";
}

}
