package com.fujitsu.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fujitsu.test.ConnectionUtil;
import com.fujitsu.test.FeedBackComments;
import com.fujitsu.test.FeedBackDao;

/**
 * Servlet implementation class TrainerBatch1Servlet
 */
@WebServlet("/TrainerBatch1Servlet")
public class TrainerBatch1Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TrainerBatch1Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		Connection connection = ConnectionUtil.getConnection();
		try {
			List<FeedBackComments> users = FeedBackDao.feedBackComments();
			if (!users.isEmpty()) {
				RequestDispatcher rd = request.getRequestDispatcher("Traineelist.jsp");
				request.setAttribute("usersList", users);
				rd.forward(request, response);
			} else {
				RequestDispatcher rd = request.getRequestDispatcher("Traineelist.jsp");
				request.setAttribute("MESSAGE", "No Users Found. Add User.");
				rd.forward(request, response);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			RequestDispatcher rd = request.getRequestDispatcher("LoginPage.html");
			request.setAttribute("MESSAGE", e.getMessage());
			rd.forward(request, response);
		}

	}

		/*String sql =  "select registers.username,registers.batch,feedbacks.comments from registers inner join feedbacks on registers.username=feedbacks.username";
		PreparedStatement pst;
		String username=null;
		String batch=null;
		String comments=null;
		try {
			pst = connection.prepareStatement(sql);
			ResultSet rs= pst.executeQuery(sql);
	        if (rs.next()) {
	        	 username=rs.getString("username");
	        	 batch=rs.getString("batch");
	        	 comments=rs.getString("comments");
	        	
	        }
	        FeedBackComments feedback=new FeedBackComments(username,batch,comments);
	        FeedBackController.feedBackComments(feedback);
	        response.sendRedirect("list.jsp");
	}catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}*/
	

	
}

