package com.fujitsu.servlets;



import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fujitsu.test.FeedBack;
import com.fujitsu.test.FeedBackController;


/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("username");
		String email = request.getParameter("email");
		String designation = request.getParameter("designation");
		String batch=request.getParameter("batch");
		Long contactnumber=Long.parseLong(request.getParameter("contactNumber"));
		String password=request.getParameter("password_1");
		String confirmpassword=request.getParameter("password_2");
		if(password.equals(confirmpassword)){
			FeedBack feedback = new FeedBack(name, email,designation,batch,contactnumber,password);
			FeedBackController.add(feedback);
			
			 response.sendRedirect("LoginPage.html");
			}
			else{
				response.getWriter().print("Password and Confirm Password must be same");
				response.setContentType("text/html");
				RequestDispatcher rd = request.getRequestDispatcher("Register.html");
				rd.include(request, response);
			}
		//FeedBackController controller = new FeedBackController();
		
//		List<FeedBack> feedbacks=null;
//		try {
//			feedbacks = controller.findAll();
//			request.setAttribute("FEEDBACK", feedbacks);
//			RequestDispatcher rd = request.getRequestDispatcher("list.jsp");
//			rd.forward(request, response);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
	}

}
