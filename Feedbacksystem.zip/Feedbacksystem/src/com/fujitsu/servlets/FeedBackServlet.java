package com.fujitsu.servlets;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fujitsu.test.FeedBackController;
import com.fujitsu.test.FeedBackModel;




/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/FeedBackServlet")
public class FeedBackServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("username");
		String comments = request.getParameter("comments");
		
		FeedBackModel feedback = new FeedBackModel(name, comments);
		FeedBackController.update(feedback);
		response.sendRedirect("TraineeFeedbackPage.html");
		/*FeedBackModel user = new FeedBackModel();
		user.setUsername(name);
		user.setComments(comments);
		FeedBackDao dao = new FeedBackDao();
		try {
			dao.update(user);
			response.sendRedirect("ListServlet");
		} catch (Exception e) {
			e.printStackTrace();
			RequestDispatcher rd = request.getRequestDispatcher("edit.jsp");
			request.setAttribute("MESSAGE", e.getMessage());
			rd.forward(request, response);
		}*/

	}

}