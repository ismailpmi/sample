package com.fujitsu.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fujitsu.test.ConnectionUtil;



/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Connection connection = ConnectionUtil.getConnection();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		String sql = "select * from registers where username='" + username + "' and password='" + password + "'";
		PreparedStatement pst;
		try {
			if(username.equals("admin@gmail.com") && password.equals("admin")){
				 response.sendRedirect("admin.html");
			}
			else{
			pst = connection.prepareStatement(sql);
			ResultSet rs= pst.executeQuery(sql);
	        if (rs.next()) {
	      if(rs.getString("designation").equals("Trainee")){
	            response.sendRedirect("TraineeFeedbackPage.html");
	      }
	      else if(rs.getString("designation").equals("Trainer")){
	    	  if(rs.getString("batch").equals("Batch1")){
	    	  response.sendRedirect("TrainerBatch1.jsp");
	      }
	    	  else{
	    		  response.sendRedirect("TrainerBatch2.jsp");
	    	  }
	      }
	      else{
	    	  response.getWriter().print("User doesn't exists..Please register with your credentials");
				response.setContentType("text/html");
				RequestDispatcher rd = request.getRequestDispatcher("RegisterationPage.html");
				rd.include(request, response);
	      }
	        } else {
	        	
	        	response.getWriter().print("Invalid username/password");
				response.setContentType("text/html");
				RequestDispatcher rd = request.getRequestDispatcher("LoginPage.html");
				rd.include(request, response);
	            
	        }
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		

	}
}